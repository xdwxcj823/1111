<?php
/**
* autoload: true
* author: 我
* description: B站-沙雕仙逆
* version: 1.0
 * B站视频爬虫 - Apple CMS模板版
 * 支持首页、分类、详情、播放
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');

class BiliBiliSpider {
    private $header = [
        "User-Agent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Referer" => "https://www.bilibili.com"
    ];
    
    // B站官方主要分区ID映射
    private $categories = [
        ["type_id" => "hot", "type_name" => "热门推荐"],
        ["type_id" => "1", "type_name" => "动画"],
        ["type_id" => "3", "type_name" => "音乐"],
        ["type_id" => "129", "type_name" => "舞蹈"],
        ["type_id" => "4", "type_name" => "游戏"],
        ["type_id" => "36", "type_name" => "知识"],
        ["type_id" => "188", "type_name" => "科技"],
        ["type_id" => "234", "type_name" => "运动"],
        ["type_id" => "223", "type_name" => "汽车"],
        ["type_id" => "160", "type_name" => "生活"],
        ["type_id" => "211", "type_name" => "美食"],
        ["type_id" => "217", "type_name" => "动物圈"],
        ["type_id" => "119", "type_name" => "鬼畜"],
        ["type_id" => "155", "type_name" => "时尚"],
        ["type_id" => "202", "type_name" => "资讯"],
        ["type_id" => "5", "type_name" => "娱乐"],
        ["type_id" => "181", "type_name" => "影视"],
        ["type_id" => "177", "type_name" => "纪录片"],
        ["type_id" => "23", "type_name" => "电影"],
        ["type_id" => "11", "type_name" => "电视剧"]
    ];

    private function httpRequest($url, $params = []) {
        $ch = curl_init();
        
        if (!empty($params)) {
            $url .= '?' . http_build_query($params);
        }
        
        $headers = [];
        foreach ($this->header as $key => $value) {
            $headers[] = $key . ': ' . $value;
        }
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => 'gzip'
        ]);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        return json_decode($response, true) ?: [];
    }

    // 首页
    public function home() {
        $result = [
            'class' => $this->categories
        ];
        
        // 首页推荐视频
        $videos = $this->getPopularVideos(1, 20);
        $result['list'] = $videos['list'];
        
        return $result;
    }

    // 分类页 - 所有分类都使用分区API
    public function category($tid, $pg, $filter) {
        $page = max(1, intval($pg));
        
        if ($tid === 'hot') {
            // 热门推荐
            return $this->getPopularVideos($page, 20);
        } else {
            // 所有数字ID都使用分区API
            return $this->getRegionVideos($tid, $page, 20);
        }
    }

    // 搜索页 - 完全放开搜索
    public function search($wd, $pg) {
        $page = max(1, intval($pg));
        
        // 如果搜索关键词为空，返回空结果
        if (empty(trim($wd))) {
            return [
                'list' => [],
                'page' => $page,
                'pagecount' => 1,
                'limit' => 20,
                'total' => 0
            ];
        }
        
        return $this->searchVideos($wd, $page, 20);
    }

    // 详情页
    public function detail($ids) {
        $url = 'https://api.bilibili.com/x/web-interface/view';
        $data = $this->httpRequest($url, ['aid' => $ids]);
        
        if (!isset($data['data'])) {
            return ['list' => []];
        }
        
        $video = $data['data'];
        
        // 构建播放列表
        $playFrom = 'B站视频';
        $playUrl = '';
        
        if (count($video['pages']) > 1) {
            // 多P视频
            foreach ($video['pages'] as $index => $page) {
                $part = $page['part'] ?: '第' . ($index + 1) . '集';
                $playUrl .= $part . '$' . $ids . '_' . $page['cid'] . '#';
            }
        } else {
            // 单P视频
            $playUrl = '正片$' . $ids . '_' . $video['pages'][0]['cid'];
        }
        
        $vod = [
            "vod_id" => $ids,
            "vod_name" => strip_tags($video['title']),
            "vod_pic" => $video['pic'] . '@672w_378h_1c',
            "type_name" => $this->getTypeName($video['tid']),
            "vod_year" => date('Y', $video['ctime']),
            "vod_area" => "中国",
            "vod_actor" => "UP主：" . ($video['owner']['name'] ?? ''),
            "vod_director" => $video['owner']['name'] ?? '',
            "vod_content" => $video['desc'],
            "vod_play_from" => $playFrom,
            "vod_play_url" => trim($playUrl, '#')
        ];
        
        return ['list' => [$vod]];
    }

    // 播放页 - 直接返回播放URL
    public function play($id, $flags) {
        if (strpos($id, '_') === false) {
            return [
                'parse' => 0,
                'url' => '',
                'header' => $this->header
            ];
        }
        
        list($avid, $cid) = explode('_', $id);
        
        // 方法1: 使用官方API获取播放地址
        $url = 'https://api.bilibili.com/x/player/playurl';
        $params = [
            'avid' => $avid,
            'cid' => $cid,
            'qn' => 116, // 高清
            'fnval' => 16,
            'fourk' => 1
        ];
        
        $data = $this->httpRequest($url, $params);
        
        $playUrl = '';
        if (isset($data['data']['durl'][0]['url'])) {
            $playUrl = $data['data']['durl'][0]['url'];
        }
        
        // 方法2: 如果官方API失败，使用备用地址
        if (empty($playUrl)) {
            $playUrl = $this->getBackupPlayUrl($avid, $cid);
        }
        
        // 方法3: 如果还是失败，使用第三方解析
        if (empty($playUrl)) {
            $playUrl = $this->getThirdPartyPlayUrl($avid, $cid);
        }
        
        $headers = $this->header;
        $headers['Referer'] = 'https://www.bilibili.com/video/av' . $avid;
        $headers['Origin'] = 'https://www.bilibili.com';
        
        return [
            'parse' => 0, // 0表示直接播放，不需要解析
            'url' => $playUrl,
            'header' => $headers
        ];
    }
    
    // 获取备用播放地址
    private function getBackupPlayUrl($avid, $cid) {
        // 尝试多种备用地址格式
        $backupUrls = [
            "https://cn-bj-cc-01-12.bilivideo.com/upgcxcode/21/73/{$cid}/{$cid}-1-80.flv",
            "https://upos-sz-mirrorcos.bilivideo.com/upgcxcode/21/73/{$cid}/{$cid}-1-80.flv",
            "https://cn-gdfs-ct-01-12.bilivideo.com/upgcxcode/21/73/{$cid}/{$cid}-1-80.flv"
        ];
        
        foreach ($backupUrls as $url) {
            if ($this->checkUrlAccessible($url)) {
                return $url;
            }
        }
        
        return '';
    }
    
    // 获取第三方解析地址
    private function getThirdPartyPlayUrl($avid, $cid) {
        // 使用第三方B站解析服务
        $thirdPartyUrls = [
            "https://api.bilibili.com/x/player/playurl?avid={$avid}&cid={$cid}&qn=80&type=mp4",
            "https://api.injahow.cn/bparse/?av={$avid}&cid={$cid}",
            "https://b.2024666.xyz/?url=https://www.bilibili.com/video/av{$avid}"
        ];
        
        foreach ($thirdPartyUrls as $url) {
            $result = $this->httpRequest($url);
            if (isset($result['url']) && !empty($result['url'])) {
                return $result['url'];
            }
            if (isset($result['data']['url']) && !empty($result['data']['url'])) {
                return $result['data']['url'];
            }
        }
        
        return '';
    }
    
    // 检查URL是否可访问
    private function checkUrlAccessible($url) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_NOBODY => true,
            CURLOPT_TIMEOUT => 5,
            CURLOPT_FOLLOWLOCATION => true
        ]);
        curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return $httpCode === 200;
    }

    // 获取热门视频
    private function getPopularVideos($page = 1, $limit = 20) {
        $url = 'https://api.bilibili.com/x/web-interface/popular';
        $data = $this->httpRequest($url, ['ps' => $limit, 'pn' => $page]);
        
        $videos = [];
        if (isset($data['data']['list'])) {
            foreach ($data['data']['list'] as $item) {
                $videos[] = [
                    'vod_id' => $item['aid'],
                    'vod_name' => strip_tags($item['title']),
                    'vod_pic' => $item['pic'] . '@672w_378h_1c',
                    'vod_remarks' => $this->formatViewCount($item['stat']['view']) . '播放'
                ];
            }
        }
        
        return [
            'list' => $videos,
            'page' => $page,
            'pagecount' => 5,
            'limit' => $limit,
            'total' => 100
        ];
    }

    // 获取分区视频
    private function getRegionVideos($tid, $page = 1, $limit = 20) {
        $url = 'https://api.bilibili.com/x/web-interface/dynamic/region';
        $data = $this->httpRequest($url, [
            'ps' => $limit,
            'pn' => $page,
            'rid' => $tid
        ]);
        
        $videos = [];
        if (isset($data['data']['archives'])) {
            foreach ($data['data']['archives'] as $item) {
                $videos[] = [
                    'vod_id' => $item['aid'],
                    'vod_name' => strip_tags($item['title']),
                    'vod_pic' => $item['pic'] . '@672w_378h_1c',
                    'vod_remarks' => $this->formatViewCount($item['stat']['view']) . '播放'
                ];
            }
        }
        
        return [
            'list' => $videos,
            'page' => $page,
            'pagecount' => 10,
            'limit' => $limit,
            'total' => 200
        ];
    }

    // 搜索视频 - 完全放开搜索
    private function searchVideos($keyword, $page = 1, $limit = 20) {
        $url = 'https://api.bilibili.com/x/web-interface/search/type';
        $data = $this->httpRequest($url, [
            'search_type' => 'video',
            'keyword' => $keyword,
            'page' => $page,
            'pagesize' => $limit
        ]);
        
        $videos = [];
        if (isset($data['data']['result'])) {
            foreach ($data['data']['result'] as $item) {
                $videos[] = [
                    'vod_id' => $item['aid'],
                    'vod_name' => strip_tags($item['title']),
                    'vod_pic' => 'https:' . $item['pic'] . '@672w_378h_1c',
                    'vod_remarks' => $this->formatDuration($item['duration'])
                ];
            }
        }
        
        $pageCount = $data['data']['numPages'] ?? 1;
        $total = $data['data']['numResults'] ?? count($videos);
        
        return [
            'list' => $videos,
            'page' => $page,
            'pagecount' => $pageCount,
            'limit' => $limit,
            'total' => $total
        ];
    }

    // 工具函数
    private function getTypeName($tid) {
        foreach ($this->categories as $cat) {
            if ($cat['type_id'] == $tid) {
                return $cat['type_name'];
            }
        }
        return '其他';
    }

    private function formatViewCount($count) {
        if ($count >= 10000) {
            return round($count / 10000, 1) . '万';
        }
        return $count;
    }

    private function formatDuration($duration) {
        $parts = explode(':', $duration);
        if (count($parts) === 2) {
            return $parts[0] . ':' . $parts[1];
        }
        return '00:00';
    }
}

// Apple CMS标准接口
$spider = new BiliBiliSpider();

// 获取参数
$ac = $_GET['ac'] ?? '';
$t = $_GET['t'] ?? '';
$pg = $_GET['pg'] ?? '1';
$wd = $_GET['wd'] ?? '';
$ids = $_GET['ids'] ?? '';
$id = $_GET['id'] ?? '';
$filter = $_GET['filter'] ?? '';

try {
    switch ($ac) {
        // 首页
        case '':
        case 'detail':
            if (empty($ids) && empty($t)) {
                echo json_encode($spider->home(), JSON_UNESCAPED_UNICODE);
            } elseif (!empty($ids)) {
                echo json_encode($spider->detail($ids), JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode($spider->category($t, $pg, $filter), JSON_UNESCAPED_UNICODE);
            }
            break;
            
        // 搜索 - 完全放开搜索
        case 'search':
            echo json_encode($spider->search($wd, $pg), JSON_UNESCAPED_UNICODE);
            break;
            
        // 播放
        case 'play':
            echo json_encode($spider->play($id, ''), JSON_UNESCAPED_UNICODE);
            break;
            
        default:
            echo json_encode(['error' => '未知操作'], JSON_UNESCAPED_UNICODE);
    }
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
?>