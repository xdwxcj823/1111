<?php
/**
 * TVBox PHP 爬虫脚本 - 磁力增强版
 * 支持JSON/TXT/M3U/DB文件格式 + 磁力链接 + ed2k链接
 * 完整磁力文件夹扫描和智能命名功能
 */
ini_set('memory_limit', '-1');
// 获取请求参数
$操作类型 = $_GET['ac'] ?? 'detail';
$分类标识 = $_GET['t'] ?? '';
$页码 = $_GET['pg'] ?? '1';
$视频标识 = $_GET['ids'] ?? '';
$搜索关键词 = $_GET['wd'] ?? '';
$播放标志 = $_GET['flag'] ?? '';
$播放标识 = $_GET['id'] ?? '';

// 设置响应头为 JSON
header('Content-Type: application/json; charset=utf-8');

// 性能优化 - 增加超时时间
@set_time_limit(30);

// 根据不同 action 返回数据
switch ($操作类型) {
    case 'detail':
        if (!empty($视频标识)) {
            $结果 = 获取详情($视频标识);
        } elseif (!empty($分类标识)) {
            $结果 = 获取分类($分类标识, $页码);
        } else {
            $结果 = 获取首页();
        }
        break;
    
    case 'search':
        $结果 = 搜索($搜索关键词, $页码);
        break;
        
    case 'play':
        $结果 = 获取播放($播放标志, $播放标识);
        break;
    
    default:
        $结果 = ['错误' => '未知操作: ' . $操作类型];
}

echo json_encode($结果, JSON_UNESCAPED_UNICODE);

/**
 * 递归扫描目录 - 支持无限级子文件夹
 */
function 递归扫描目录($目录, $文件类型, $当前深度 = 0, $最大深度 = 20) {
    $文件列表 = [];
    
    if (!is_dir($目录)) {
        return $文件列表;
    }
    
    if ($当前深度 > $最大深度) {
        return $文件列表;
    }
    
    $目录项 = @scandir($目录);
    if ($目录项 === false) {
        return $文件列表;
    }
    
    foreach ($目录项 as $项目) {
        if ($项目 === '.' || $项目 === '..') continue;
        
        $路径 = $目录 . $项目;
        
        if (is_dir($路径)) {
            $子文件 = 递归扫描目录($路径 . '/', $文件类型, $当前深度 + 1, $最大深度);
            $文件列表 = array_merge($文件列表, $子文件);
        } else {
            $扩展名 = strtolower(pathinfo($路径, PATHINFO_EXTENSION));
            if (in_array($扩展名, $文件类型)) {
                $相对路径 = str_replace('/storage/emulated/0/江湖/', '', $路径);
                
                // 检查是否为磁力文件夹
                $是磁力文件夹 = (strpos($路径, '/江湖/wj/bt/') !== false);
                
                $文件列表[] = [
                    'type' => $扩展名,
                    'path' => $路径,
                    'name' => $项目,
                    'filename' => pathinfo($项目, PATHINFO_FILENAME),
                    'relative_path' => $相对路径,
                    'depth' => $当前深度,
                    'is_magnet_folder' => $是磁力文件夹
                ];
            }
        }
    }
    
    return $文件列表;
}

/**
 * 获取所有文件列表 - 增强磁力文件夹支持
 */
function 获取所有文件() {
    static $所有文件 = null;
    
    if ($所有文件 === null) {
        $所有文件 = [];
        
        $JSON文件 = 递归扫描目录('/storage/emulated/0/江湖/json/影视/', ['json']);
        $TXT文件 = 递归扫描目录('/storage/emulated/0/江湖/wj/', ['txt']);
        $M3U文件 = array_merge(
            递归扫描目录('/storage/emulated/0/江湖/json/影视/', ['m3u']),
            递归扫描目录('/storage/emulated/0/江湖/wj/', ['m3u'])
        );
        
        // 增强数据库文件扫描，包含bt磁力文件夹
        $数据库文件 = array_merge(
            递归扫描目录('/storage/emulated/0/江湖/json/影视/', ['db']),
            递归扫描目录('/storage/emulated/0/江湖/wj/', ['db']),
            递归扫描目录('/storage/emulated/0/江湖/db/', ['db']),
            递归扫描目录('/storage/emulated/0/江湖/wj/bt/', ['db'])
        );
        
        $所有文件 = array_merge($JSON文件, $TXT文件, $M3U文件, $数据库文件);
        
        // 按路径排序
        usort($所有文件, function($甲, $乙) {
            return strcmp($甲['relative_path'], $乙['relative_path']);
        });
    }
    
    return $所有文件;
}

/**
 * 估算文件中的视频数量（快速估算，不实际解析）
 */
function 估算文件视频数量($文件) {
    $路径 = $文件['path'];
    $类型 = $文件['type'];
    
    if (!file_exists($路径)) {
        return 0;
    }
    
    $文件大小 = filesize($路径);
    
    // 根据文件类型和大小快速估算
    switch ($类型) {
        case 'json':
            $数量 = $文件大小 > 1024 ? intval($文件大小 / 1024) : 1;
            break;
        case 'txt':
            $行数 = $文件大小 > 100 ? intval($文件大小 / 100) : 1;
            $数量 = min($行数, 10000);
            break;
        case 'm3u':
            $行数 = $文件大小 > 200 ? intval($文件大小 / 200) : 1;
            $数量 = min($行数, 5000);
            break;
        case 'db':
            $数量 = $文件大小 > 500 ? intval($文件大小 / 500) : 1;
            break;
        default:
            $数量 = 0;
    }
    
    return $数量;
}

/**
 * 获取分类列表
 */
function 获取分类列表() {
    static $分类列表 = null;
    
    if ($分类列表 === null) {
        $所有文件 = 获取所有文件();
        $分类列表 = [];
        
        // 新增热门推荐分类
        $总文件数 = count($所有文件);
        $分类列表[] = [
            'type_id' => 'hot',
            'type_name' => '🔥热门推荐 (' . $总文件数 . '个文件)',
            'type_file' => 'hot_recommend',
            'source_path' => 'hot',
            'source_type' => 'hot'
        ];
        
        // 用于去重的数组
        $已处理文件 = [];
        
        // 文件分类（显示所有文件）
        foreach ($所有文件 as $索引 => $文件) {
            // 去重：基于文件路径和名称
            $文件标识 = $文件['path'] . '|' . $文件['name'];
            if (in_array($文件标识, $已处理文件)) {
                continue;
            }
            $已处理文件[] = $文件标识;
            
            $文件类型 = '';
            $类型图标 = '';
            
            switch ($文件['type']) {
                case 'json':
                    $文件类型 = '[JSON] ';
                    $类型图标 = '📊 ';
                    break;
                case 'txt':
                    $文件类型 = '[TXT] ';
                    $类型图标 = '📄 ';
                    break;
                case 'm3u':
                    $文件类型 = '[M3U] ';
                    $类型图标 = '📺 ';
                    break;
                case 'db':
                    $文件类型 = '[数据库] ';
                    $类型图标 = '🗃️ ';
                    break;
            }
            
            // 磁力文件夹标识
            if ($文件['is_magnet_folder']) {
                $类型图标 = '🧲 ';
                $文件类型 = '[磁力] ';
            }
            
            // 显示文件夹路径
            $文件夹信息 = '';
            if (strpos($文件['relative_path'], '/') !== false) {
                $文件夹路径 = dirname($文件['relative_path']);
                $文件夹信息 = ' 📁 ' . $文件夹路径;
            }
            
            // 估算每个文件的视频数量
            $视频数量 = 估算文件视频数量($文件);
            $数量显示 = $视频数量 > 0 ? ' (' . number_format($视频数量) . '个视频)' : '';
            
            $分类列表[] = [
                'type_id' => (string)($索引 + 1),
                'type_name' => $类型图标 . $文件类型 . $文件['filename'] . $数量显示 . $文件夹信息,
                'type_file' => $文件['name'],
                'source_path' => $文件['path'],
                'source_type' => $文件['type'],
                'video_count' => $视频数量,
                'is_magnet_folder' => $文件['is_magnet_folder']
            ];
        }
        
        if (empty($所有文件)) {
            $分类列表[] = [
                'type_id' => '1',
                'type_name' => '❓ 未找到媒体文件',
                'type_file' => 'empty',
                'source_path' => 'empty',
                'source_type' => 'empty'
            ];
        }
    }
    
    return $分类列表;
}

/**
 * 解析SQLite数据库文件内容 - 增强磁力链接和JSON支持
 */
function 解析数据库文件($文件路径) {
    if (!file_exists($文件路径)) {
        return ['错误' => '数据库文件不存在: ' . basename($文件路径)];
    }
    
    $文件大小 = filesize($文件路径);
    $可读 = is_readable($文件路径);
    
    if ($文件大小 === 0) {
        return ['错误' => '数据库文件为空: ' . basename($文件路径)];
    }
    
    if (!$可读) {
        return ['错误' => '数据库文件不可读: ' . basename($文件路径)];
    }
    
    if (!extension_loaded('pdo_sqlite')) {
        return ['错误' => 'PDO_SQLite扩展不可用，无法读取数据库文件'];
    }
    
    try {
        $数据库 = new PDO("sqlite:" . $文件路径);
        $数据库->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $视频列表 = [];
        
        $表列表 = $数据库->query("SELECT name FROM sqlite_master WHERE type='table'")->fetchAll(PDO::FETCH_COLUMN);
        
        if (empty($表列表)) {
            return ['错误' => '数据库中未找到任何数据表'];
        }
        
        $默认图片 = [
            'https://www.252035.xyz/imgs?t=1335527662'
        ];
        
        foreach ($表列表 as $表名) {
            if (strpos($表名, 'sqlite_') === 0) continue;
            
            $字段列表 = $数据库->query("PRAGMA table_info($表名)")->fetchAll(PDO::FETCH_ASSOC);
            $字段名称 = array_column($字段列表, 'name');
            
            // 特殊处理：如果表有data字段，假设它包含JSON数据
            if (in_array('data', $字段名称)) {
                $结果集 = $数据库->query("SELECT data FROM $表名")->fetchAll(PDO::FETCH_COLUMN);
                
                foreach ($结果集 as $索引 => $json数据) {
                    if (empty($json数据)) continue;
                    
                    $视频数据 = json_decode($json数据, true);
                    if ($视频数据 && is_array($视频数据)) {
                        $视频名称 = $视频数据['name'] ?? $视频数据['title'] ?? '未知视频';
                        $视频链接 = '';
                        $播放来源 = '数据库源';
                        
                        if (isset($视频数据['magnet']) && !empty($视频数据['magnet'])) {
                            $视频链接 = $视频数据['magnet'];
                            $播放来源 = '🧲磁力链接';
                        } elseif (isset($视频数据['magnet_url']) && !empty($视频数据['magnet_url'])) {
                            $视频链接 = $视频数据['magnet_url'];
                            $播放来源 = '🧲磁力链接';
                        } elseif (isset($视频数据['url']) && !empty($视频数据['url'])) {
                            $视频链接 = $视频数据['url'];
                            if (strpos($视频链接, 'magnet:') === 0) {
                                $播放来源 = '🧲磁力链接';
                            }
                        }
                        
                        if (empty($视频链接)) {
                            continue;
                        }
                        
                        $视频封面 = $视频数据['cover'] ?? $视频数据['image'] ?? $视频数据['poster'] ?? $默认图片[$索引 % count($默认图片)];
                        $视频描述 = $视频数据['description'] ?? $视频数据['desc'] ?? $视频数据['content'] ?? '《' . $视频名称 . '》的精彩内容';
                        $视频年份 = $视频数据['year'] ?? date('Y');
                        $视频地区 = $视频数据['area'] ?? $视频数据['region'] ?? '未知地区';
                        
                        $视频列表[] = [
                            'vod_id' => 'db_' . md5($文件路径) . '_' . $表名 . '_' . $索引,
                            'vod_name' => $视频名称,
                            'vod_pic' => $视频封面,
                            'vod_remarks' => '高清',
                            'vod_year' => $视频年份,
                            'vod_area' => $视频地区,
                            'vod_content' => $视频描述,
                            'vod_play_from' => $播放来源,
                            'vod_play_url' => '正片$' . $视频链接
                        ];
                    }
                }
            } else {
                $名称字段 = null;
                $链接字段 = null;
                $磁力字段 = null;
                $电驴字段 = null;
                $图片字段 = null;
                $描述字段 = null;
                $年份字段 = null;
                $地区字段 = null;
                $JSON字段 = null;
                
                foreach ($字段名称 as $字段) {
                    $小写字段 = strtolower($字段);
                    if (in_array($小写字段, ['name', 'title', 'vod_name', 'filename', 'video_name'])) {
                        $名称字段 = $字段;
                    } elseif (in_array($小写字段, ['url', 'link', 'vod_url', 'play_url', 'video_url', 'torrent'])) {
                        $链接字段 = $字段;
                    } elseif (in_array($小写字段, ['magnet', 'magnet_url', 'magnet_link'])) {
                        $磁力字段 = $字段;
                    } elseif (in_array($小写字段, ['ed2k', 'ed2k_url', 'ed2k_link'])) {
                        $电驴字段 = $字段;
                    } elseif (in_array($小写字段, ['pic', 'image', 'cover', 'vod_pic', 'poster'])) {
                        $图片字段 = $字段;
                    } elseif (in_array($小写字段, ['desc', 'description', 'content', 'vod_content'])) {
                        $描述字段 = $字段;
                    } elseif (in_array($小写字段, ['year', 'vod_year'])) {
                        $年份字段 = $字段;
                    } elseif (in_array($小写字段, ['area', 'region', 'vod_area'])) {
                        $地区字段 = $字段;
                    } elseif (in_array($小写字段, ['json', 'data', 'vod_data'])) {
                        $JSON字段 = $字段;
                    }
                }
                
                if ($名称字段) {
                    $选择字段 = [$名称字段];
                    if ($链接字段) $选择字段[] = $链接字段;
                    if ($磁力字段) $选择字段[] = $磁力字段;
                    if ($电驴字段) $选择字段[] = $电驴字段;
                    if ($图片字段) $选择字段[] = $图片字段;
                    if ($描述字段) $选择字段[] = $描述字段;
                    if ($年份字段) $选择字段[] = $年份字段;
                    if ($地区字段) $选择字段[] = $地区字段;
                    if ($JSON字段) $选择字段[] = $JSON字段;
                    
                    $查询SQL = "SELECT " . implode(', ', $选择字段) . " FROM $表名";
                    
                    $语句 = $数据库->query($查询SQL);
                    $结果集 = $语句->fetchAll(PDO::FETCH_ASSOC);
                    
                    foreach ($结果集 as $索引 => $行数据) {
                        $视频名称 = $行数据[$名称字段] ?? '未知视频';
                        
                        if ($JSON字段 && !empty($行数据[$JSON字段])) {
                            $json数据 = json_decode($行数据[$JSON字段], true);
                            if ($json数据 && is_array($json数据)) {
                                if (isset($json数据['name']) && empty($视频名称)) {
                                    $视频名称 = $json数据['name'];
                                }
                            }
                        }
                        
                        $视频链接 = '';
                        $播放来源 = '数据库源';
                        
                        if ($磁力字段 && !empty($行数据[$磁力字段])) {
                            $视频链接 = $行数据[$磁力字段];
                            $播放来源 = '🧲磁力链接';
                        } elseif ($电驴字段 && !empty($行数据[$电驴字段])) {
                            $视频链接 = $行数据[$电驴字段];
                            $播放来源 = '⚡电驴链接';
                        } elseif ($链接字段 && !empty($行数据[$链接字段])) {
                            $视频链接 = $行数据[$链接字段];
                            if (strpos($视频链接, 'magnet:') === 0) {
                                $播放来源 = '🧲磁力链接';
                            } elseif (strpos($视频链接, 'ed2k://') === 0) {
                                $播放来源 = '⚡电驴链接';
                            }
                        }
                        
                        if (empty($视频链接)) {
                            continue;
                        }
                        
                        $视频封面 = $行数据[$图片字段] ?? $默认图片[$索引 % count($默认图片)];
                        $视频描述 = $行数据[$描述字段] ?? '《' . $视频名称 . '》的精彩内容';
                        $视频年份 = $行数据[$年份字段] ?? date('Y');
                        $视频地区 = $行数据[$地区字段] ?? '中国大陆';
                        
                        $有效协议 = ['http://', 'https://', 'rtmp://', 'rtsp://', 'udp://', 'magnet:', 'ed2k://'];
                        $有有效协议 = false;
                        foreach ($有效协议 as $协议) {
                            if (stripos($视频链接, $协议) === 0) {
                                $有有效协议 = true;
                                break;
                            }
                        }
                        
                        if (!$有有效协议) {
                            continue;
                        }
                        
                        $视频列表[] = [
                            'vod_id' => 'db_' . md5($文件路径) . '_' . $表名 . '_' . $索引,
                            'vod_name' => $视频名称,
                            'vod_pic' => $视频封面,
                            'vod_remarks' => '高清',
                            'vod_year' => $视频年份,
                            'vod_area' => $视频地区,
                            'vod_content' => $视频描述,
                            'vod_play_from' => $播放来源,
                            'vod_play_url' => '正片$' . $视频链接
                        ];
                        
                        if (count($视频列表) >= 1000) {
                            break 2;
                        }
                    }
                }
            }
        }
        
        $数据库 = null;
        
        return $视频列表;
        
    } catch (PDOException $异常) {
        return ['错误' => '数据库读取失败: ' . $异常->getMessage()];
    }
}

/**
 * 解析JSON文件内容 - 完整加载
 */
function 解析JSON文件($文件路径) {
    if (!file_exists($文件路径)) {
        return ['错误' => 'JSON文件不存在: ' . basename($文件路径)];
    }
    
    $JSON内容 = @file_get_contents($文件路径);
    if ($JSON内容 === false) {
        return ['错误' => '无法读取JSON文件: ' . basename($文件路径)];
    }
    
    if (substr($JSON内容, 0, 3) == "\xEF\xBB\xBF") {
        $JSON内容 = substr($JSON内容, 3);
    }
    
    $数据 = json_decode($JSON内容, true);
    if (!$数据) {
        return ['错误' => 'JSON格式无效: ' . basename($文件路径)];
    }
    
    if (!isset($数据['list']) || !is_array($数据['list'])) {
        return ['错误' => 'JSON格式无效或缺少list字段: ' . basename($文件路径)];
    }
    
    return $数据['list'];
}

/**
 * 智能生成视频名称
 */
function 生成视频名称($链接, $默认名称 = '未知视频') {
    if (strpos($链接, 'magnet:?xt=urn:btih:') === 0) {
        if (preg_match('/&dn=([^&]+)/i', $链接, $匹配)) {
            $名称 = urldecode($匹配[1]);
            return $名称 ?: '磁力资源';
        }
        return '磁力资源';
    }
    
    if (strpos($链接, 'ed2k://') === 0) {
        if (preg_match('/\|file\|([^\|]+)\|/i', $链接, $匹配)) {
            $名称 = urldecode($匹配[1]);
            return $名称 ?: '电驴资源';
        }
        return '电驴资源';
    }
    
    return $默认名称;
}

/**
 * 解析TXT文件内容 - 增强磁力链接和纯链接支持
 */
function 解析TXT文件($文件路径) {
    if (!file_exists($文件路径)) {
        return ['错误' => 'TXT文件不存在: ' . basename($文件路径)];
    }
    
    $句柄 = @fopen($文件路径, 'r');
    if (!$句柄) {
        return ['错误' => '无法打开TXT文件: ' . basename($文件路径)];
    }
    
    $视频列表 = [];
    $视频数量 = 0;
    $行号 = 0;
    
    $默认图片 = [
        'https://www.252035.xyz/imgs?t=1335527662'
    ];
    
    $首行 = fgets($句柄);
    rewind($句柄);
    $有BOM = (substr($首行, 0, 3) == "\xEF\xBB\xBF");
    if ($有BOM) {
        fseek($句柄, 3);
    }
    
    $内存限制 = 50 * 1024 * 1024;
    $起始内存 = memory_get_usage();
    
    while (($行 = fgets($句柄)) !== false) {
        $行号++;
        $行 = trim($行);
        
        if ($行 === '' || $行[0] === '#' || $行[0] === ';') {
            continue;
        }
        
        if (strpos($行, 'magnet:') === 0 || strpos($行, 'ed2k://') === 0) {
            $链接 = $行;
            $名称 = 生成视频名称($链接);
        } else {
            $分隔符 = [',', "\t", '|', '$', '#'];
            $分隔符位置 = false;
            
            foreach ($分隔符 as $分隔) {
                $位置 = strpos($行, $分隔);
                if ($位置 !== false) {
                    $分隔符位置 = $位置;
                    break;
                }
            }
            
            if ($分隔符位置 === false) {
                $链接 = $行;
                $名称 = 生成视频名称($链接);
            } else {
                $名称 = trim(substr($行, 0, $分隔符位置));
                $链接 = trim(substr($行, $分隔符位置 + 1));
            }
        }
        
        if (empty($名称) || empty($链接)) {
            continue;
        }
        
        $有效协议 = ['http://', 'https://', 'rtmp://', 'rtsp://', 'udp://', 'magnet:', 'ed2k://'];
        $有有效协议 = false;
        foreach ($有效协议 as $协议) {
            if (stripos($链接, $协议) === 0) {
                $有有效协议 = true;
                break;
            }
        }
        
        if (!$有有效协议) {
            continue;
        }
        
        $图片索引 = $视频数量 % count($默认图片);
        
        $播放来源 = '在线播放';
        if (strpos($链接, 'magnet:') === 0) {
            $播放来源 = '🧲磁力链接';
        } elseif (strpos($链接, 'ed2k://') === 0) {
            $播放来源 = '⚡电驴链接';
        }
        
        $视频列表[] = [
            'vod_id' => 'txt_' . md5($文件路径) . '_' . $行号,
            'vod_name' => $名称,
            'vod_pic' => $默认图片[$图片索引],
            'vod_remarks' => '高清',
            'vod_year' => date('Y'),
            'vod_area' => '中国大陆',
            'vod_content' => '《' . $名称 . '》的精彩内容',
            'vod_play_from' => $播放来源,
            'vod_play_url' => '正片$' . $链接
        ];
        
        $视频数量++;
        
        if ($视频数量 % 100 === 0) {
            $当前内存 = memory_get_usage() - $起始内存;
            if ($当前内存 > $内存限制) {
                break;
            }
            gc_collect_cycles();
        }
        
        if ($视频数量 >= 10000) {
            break;
        }
    }
    
    fclose($句柄);
    
    return $视频列表;
}

/**
 * 解析M3U文件内容 - 增强磁力链接支持
 */
function 解析M3U文件($文件路径) {
    if (!file_exists($文件路径)) {
        return ['错误' => 'M3U文件不存在: ' . basename($文件路径)];
    }
    
    $句柄 = @fopen($文件路径, 'r');
    if (!$句柄) {
        return ['错误' => '无法打开M3U文件: ' . basename($文件路径)];
    }
    
    $视频列表 = [];
    $视频数量 = 0;
    $当前名称 = '';
    $当前图标 = '';
    $当前分组 = '';
    $行号 = 0;
    
    $默认图片 = [
        'https://www.252035.xyz/imgs?t=1335527662'
    ];
    
    $首行 = fgets($句柄);
    rewind($句柄);
    $有BOM = (substr($首行, 0, 3) == "\xEF\xBB\xBF");
    if ($有BOM) {
        fseek($句柄, 3);
    }
    
    while (($行 = fgets($句柄)) !== false) {
        $行号++;
        $行 = trim($行);
        if ($行 === '') continue;
        
        if (strpos($行, '#EXTM3U') === 0) {
            continue;
        }
        
        if (strpos($行, '#EXTINF:') === 0) {
            $当前名称 = '';
            $当前图标 = '';
            $当前分组 = '';
            
            $部分 = explode(',', $行, 2);
            if (count($部分) > 1) {
                $当前名称 = trim($部分[1]);
            }
            
            if (preg_match('/tvg-logo="([^"]*)"/i', $行, $图标匹配)) {
                $当前图标 = trim($图标匹配[1]);
            }
            
            if (preg_match('/group-title="([^"]*)"/i', $行, $分组匹配)) {
                $当前分组 = trim($分组匹配[1]);
            }
            continue;
        }
        
        $有效协议 = ['http://', 'https://', 'rtmp://', 'rtsp://', 'udp://', 'magnet:', 'ed2k://'];
        $有有效协议 = false;
        foreach ($有效协议 as $协议) {
            if (stripos($行, $协议) === 0) {
                $有有效协议 = true;
                break;
            }
        }
        
        if ($有有效协议 && !empty($当前名称)) {
            $图片索引 = $视频数量 % count($默认图片);
            
            $视频封面 = $当前图标;
            if (empty($视频封面) || !filter_var($视频封面, FILTER_VALIDATE_URL)) {
                $视频封面 = $默认图片[$图片索引];
            }
            
            $播放来源 = '直播源';
            if (!empty($当前分组)) {
                $播放来源 = $当前分组;
            }
            
            if (strpos($行, 'magnet:') === 0) {
                $播放来源 = '🧲磁力链接';
            } elseif (strpos($行, 'ed2k://') === 0) {
                $播放来源 = '⚡电驴链接';
            }
            
            $视频列表[] = [
                'vod_id' => 'm3u_' . md5($文件路径) . '_' . $行号,
                'vod_name' => $当前名称,
                'vod_pic' => $视频封面,
                'vod_remarks' => '直播',
                'vod_year' => date('Y'),
                'vod_area' => '中国大陆',
                'vod_content' => $当前名称 . '直播频道',
                'vod_play_from' => $播放来源,
                'vod_play_url' => '直播$' . $行
            ];
            
            $视频数量++;
            
            $当前名称 = '';
            $当前图标 = '';
            $当前分组 = '';
            
            if ($视频数量 >= 5000) {
                break;
            }
        }
    }
    
    fclose($句柄);
    
    return $视频列表;
}

/**
 * 获取热门推荐视频 - 从所有分类中随机获取
 */
function 获取热门视频($页码, $每页数量 = 10) {
    static $所有热门视频 = null;
    static $已使用视频标识 = [];
    
    if ($页码 == 1) {
        $已使用视频标识 = [];
    }
    
    if ($所有热门视频 === null) {
        $所有热门视频 = [];
        $所有文件 = 获取所有文件();
        
        foreach ($所有文件 as $文件) {
            if (!file_exists($文件['path'])) {
                continue;
            }
            
            $视频列表 = [];
            switch ($文件['type']) {
                case 'json':
                    $视频列表 = 解析JSON文件($文件['path']);
                    break;
                case 'txt':
                    $视频列表 = 解析TXT文件($文件['path']);
                    break;
                case 'm3u':
                    $视频列表 = 解析M3U文件($文件['path']);
                    break;
                case 'db':
                    $视频列表 = 解析数据库文件($文件['path']);
                    break;
            }
            
            if (isset($视频列表['错误'])) {
                continue;
            }
            
            if (count($视频列表) > 100) {
                $视频列表 = array_slice($视频列表, 0, 100);
            }
            
            $所有热门视频 = array_merge($所有热门视频, $视频列表);
            
            if (count($所有热门视频) > 1000) {
                break;
            }
        }
    }
    
    if (empty($所有热门视频)) {
        return [];
    }
    
    $可用视频 = [];
    foreach ($所有热门视频 as $视频) {
        $视频标识 = $视频['vod_id'] ?? '';
        if (!in_array($视频标识, $已使用视频标识)) {
            $可用视频[] = $视频;
        }
    }
    
    if (empty($可用视频)) {
        $已使用视频标识 = [];
        $可用视频 = $所有热门视频;
    }
    
    $选中视频 = [];
    $需要数量 = min($每页数量, count($可用视频));
    
    if ($需要数量 > 0) {
        $随机键 = array_rand($可用视频, $需要数量);
        if (!is_array($随机键)) {
            $随机键 = [$随机键];
        }
        
        foreach ($随机键 as $键) {
            $选中视频项 = $可用视频[$键];
            $选中视频[] = $选中视频项;
            $已使用视频标识[] = $选中视频项['vod_id'] ?? '';
        }
    }
    
    return $选中视频;
}

/**
 * 首页数据
 */
function 获取首页() {
    $分类列表 = 获取分类列表();
    
    if (empty($分类列表)) {
        return ['错误' => '未找到任何文件'];
    }
    
    return [
        'class' => $分类列表
    ];
}

/**
 * 分类列表
 */
function 获取分类($分类标识, $页码) {
    $分类列表 = 获取分类列表();
    
    if (empty($分类列表)) {
        return ['错误' => '未找到任何分类'];
    }
    
    if ($分类标识 === 'hot') {
        $当前页码 = intval($页码);
        if ($当前页码 < 1) $当前页码 = 1;
        
        $热门视频 = 获取热门视频($当前页码, 10);
        
        if (empty($热门视频)) {
            return [
                'page' => $当前页码,
                'pagecount' => 9999,
                'limit' => 10,
                'total' => 0,
                'list' => []
            ];
        }
        
        $格式化视频 = [];
        foreach ($热门视频 as $视频) {
            $格式化视频[] = 格式化视频项($视频);
        }
        
        return [
            'page' => $当前页码,
            'pagecount' => 9999,
            'limit' => 10,
            'total' => 999999,
            'list' => $格式化视频
        ];
    }
    
    $目标分类 = null;
    foreach ($分类列表 as $分类) {
        if ($分类['type_id'] === $分类标识) {
            $目标分类 = $分类;
            break;
        }
    }
    
    if (!$目标分类) {
        return ['错误' => '分类未找到: ' . $分类标识];
    }
    
    if ($目标分类['source_type'] === 'empty') {
        return [
            'page' => 1,
            'pagecount' => 1,
            'limit' => 10,
            'total' => 0,
            'list' => []
        ];
    }
    
    $分类视频 = [];
    
    if (file_exists($目标分类['source_path'])) {
        switch ($目标分类['source_type']) {
            case 'json':
                $分类视频 = 解析JSON文件($目标分类['source_path']);
                break;
            case 'txt':
                $分类视频 = 解析TXT文件($目标分类['source_path']);
                break;
            case 'm3u':
                $分类视频 = 解析M3U文件($目标分类['source_path']);
                break;
            case 'db':
                $分类视频 = 解析数据库文件($目标分类['source_path']);
                break;
        }
    }
    
    if (isset($分类视频['错误'])) {
        return ['错误' => $分类视频['错误']];
    }
    
    if (empty($分类视频)) {
        return ['错误' => '在文件中未找到视频: ' . $目标分类['type_name']];
    }
    
    $每页大小 = 10;
    $总数 = count($分类视频);
    $总页数 = ceil($总数 / $每页大小);
    $当前页码 = intval($页码);
    
    if ($当前页码 < 1) $当前页码 = 1;
    if ($当前页码 > $总页数) $当前页码 = $总页数;
    
    $起始位置 = ($当前页码 - 1) * $每页大小;
    $分页视频 = array_slice($分类视频, $起始位置, $每页大小);
    
    $格式化视频 = [];
    foreach ($分页视频 as $视频) {
        $格式化视频[] = 格式化视频项($视频);
    }
    
    return [
        'page' => $当前页码,
        'pagecount' => $总页数,
        'limit' => $每页大小,
        'total' => $总数,
        'list' => $格式化视频
    ];
}

/**
 * 格式化视频项
 */
function 格式化视频项($视频) {
    return [
        'vod_id' => $视频['vod_id'] ?? '',
        'vod_name' => $视频['vod_name'] ?? '未知视频',
        'vod_pic' => $视频['vod_pic'] ?? 'https://www.252035.xyz/imgs?t=1335527662',
        'vod_remarks' => $视频['vod_remarks'] ?? '高清',
        'vod_year' => $视频['vod_year'] ?? '',
        'vod_area' => $视频['vod_area'] ?? '中国大陆'
    ];
}

/**
 * 视频详情
 */
function 获取详情($视频标识) {
    $标识数组 = explode(',', $视频标识);
    $结果 = [];
    
    foreach ($标识数组 as $标识) {
        $视频 = 按标识查找视频($标识);
        if ($视频) {
            $结果[] = 格式化视频详情($视频);
        } else {
            $结果[] = [
                'vod_id' => $标识,
                'vod_name' => '视频 ' . $标识,
                'vod_pic' => 'https://www.252035.xyz/imgs?t=1335527662',
                'vod_remarks' => '高清',
                'vod_content' => '视频详情内容',
                'vod_play_from' => '在线播放',
                'vod_play_url' => '正片$https://example.com/video'
            ];
        }
    }
    
    return ['list' => $结果];
}

/**
 * 按标识查找视频
 */
function 按标识查找视频($标识) {
    $所有文件 = 获取所有文件();
    
    if (strpos($标识, 'txt_') === 0) {
        $部分 = explode('_', $标识);
        if (count($部分) >= 3) {
            $文件哈希 = $部分[1];
            $行号 = $部分[2];
            
            foreach ($所有文件 as $文件) {
                if ($文件['type'] === 'txt' && md5($文件['path']) === $文件哈希) {
                    return 按行查找TXT视频($文件['path'], $行号);
                }
            }
        }
    } elseif (strpos($标识, 'm3u_') === 0) {
        $部分 = explode('_', $标识);
        if (count($部分) >= 3) {
            $文件哈希 = $部分[1];
            $行号 = $部分[2];
            
            foreach ($所有文件 as $文件) {
                if ($文件['type'] === 'm3u' && md5($文件['path']) === $文件哈希) {
                    return 按行查找M3U视频($文件['path'], $行号);
                }
            }
        }
    } elseif (strpos($标识, 'db_') === 0) {
        $部分 = explode('_', $标识);
        if (count($部分) >= 4) {
            $文件哈希 = $部分[1];
            $表名 = $部分[2];
            $视频索引 = $部分[3];
            
            foreach ($所有文件 as $文件) {
                if ($文件['type'] === 'db' && md5($文件['path']) === $文件哈希) {
                    return 按索引查找数据库视频($文件['path'], $表名, $视频索引);
                }
            }
        }
    } else {
        foreach ($所有文件 as $文件) {
            if ($文件['type'] === 'json') {
                $视频列表 = 解析JSON文件($文件['path']);
                foreach ($视频列表 as $视频) {
                    if (isset($视频['vod_id']) && $视频['vod_id'] == $标识) {
                        return $视频;
                    }
                }
            }
        }
    }
    
    return null;
}

/**
 * 在TXT文件中按行号查找视频 - 增强磁力链接支持
 */
function 按行查找TXT视频($文件路径, $目标行号) {
    if (!file_exists($文件路径)) {
        return null;
    }
    
    $句柄 = @fopen($文件路径, 'r');
    if (!$句柄) {
        return null;
    }
    
    $当前行 = 0;
    $视频 = null;
    
    $默认图片 = [
        'https://www.252035.xyz/imgs?t=1335527662'
    ];
    
    $首行 = fgets($句柄);
    rewind($句柄);
    $有BOM = (substr($首行, 0, 3) == "\xEF\xBB\xBF");
    if ($有BOM) {
        fseek($句柄, 3);
    }
    
    while (($行 = fgets($句柄)) !== false) {
        $当前行++;
        $行 = trim($行);
        
        if ($行 === '' || $行[0] === '#' || $行[0] === ';') continue;
        
        if ($当前行 == $目标行号) {
            if (strpos($行, 'magnet:') === 0 || strpos($行, 'ed2k://') === 0) {
                $链接 = $行;
                $名称 = 生成视频名称($链接);
            } else {
                $分隔符 = [',', "\t", '|', '$', '#'];
                $分隔符位置 = false;
                
                foreach ($分隔符 as $分隔) {
                    $位置 = strpos($行, $分隔);
                    if ($位置 !== false) {
                        $分隔符位置 = $位置;
                        break;
                    }
                }
                
                if ($分隔符位置 !== false) {
                    $名称 = trim(substr($行, 0, $分隔符位置));
                    $链接 = trim(substr($行, $分隔符位置 + 1));
                } else {
                    $链接 = $行;
                    $名称 = 生成视频名称($链接);
                }
            }
            
            if (!empty($名称) && !empty($链接)) {
                $图片索引 = $当前行 % count($默认图片);
                
                $播放来源 = '在线播放';
                if (strpos($链接, 'magnet:') === 0) {
                    $播放来源 = '🧲磁力链接';
                } elseif (strpos($链接, 'ed2k://') === 0) {
                    $播放来源 = '⚡电驴链接';
                }
                
                $视频 = [
                    'vod_id' => 'txt_' . md5($文件路径) . '_' . $当前行,
                    'vod_name' => $名称,
                    'vod_pic' => $默认图片[$图片索引],
                    'vod_remarks' => '高清',
                    'vod_year' => date('Y'),
                    'vod_area' => '中国大陆',
                    'vod_content' => '《' . $名称 . '》的精彩内容',
                    'vod_play_from' => $播放来源,
                    'vod_play_url' => '正片$' . $链接
                ];
            }
            break;
        }
    }
    
    fclose($句柄);
    
    return $视频;
}

/**
 * 在M3U文件中按行号查找视频
 */
function 按行查找M3U视频($文件路径, $目标行号) {
    if (!file_exists($文件路径)) {
        return null;
    }
    
    $句柄 = @fopen($文件路径, 'r');
    if (!$句柄) {
        return null;
    }
    
    $当前行 = 0;
    $视频 = null;
    $当前名称 = '';
    $当前图标 = '';
    $当前分组 = '';
    
    $默认图片 = [
        'https://www.252035.xyz/imgs?t=1335527662'
    ];
    
    $首行 = fgets($句柄);
    rewind($句柄);
    $有BOM = (substr($首行, 0, 3) == "\xEF\xBB\xBF");
    if ($有BOM) {
        fseek($句柄, 3);
    }
    
    while (($行 = fgets($句柄)) !== false) {
        $当前行++;
        $行 = trim($行);
        if ($行 === '') continue;
        
        if (strpos($行, '#EXTM3U') === 0) {
            continue;
        }
        
        if (strpos($行, '#EXTINF:') === 0) {
            $当前名称 = '';
            $当前图标 = '';
            $当前分组 = '';
            
            $部分 = explode(',', $行, 2);
            if (count($部分) > 1) {
                $当前名称 = trim($部分[1]);
            }
            
            if (preg_match('/tvg-logo="([^"]*)"/i', $行, $图标匹配)) {
                $当前图标 = trim($图标匹配[1]);
            }
            
            if (preg_match('/group-title="([^"]*)"/i', $行, $分组匹配)) {
                $当前分组 = trim($分组匹配[1]);
            }
            continue;
        }
        
        if ((strpos($行, 'http') === 0 || strpos($行, 'rtmp') === 0 || 
             strpos($行, 'rtsp') === 0 || strpos($行, 'udp') === 0 ||
             strpos($行, 'magnet:') === 0 || strpos($行, 'ed2k://') === 0) && 
            !empty($当前名称)) {
            
            if ($当前行 == $目标行号) {
                $图片索引 = $当前行 % count($默认图片);
                
                $视频封面 = $当前图标;
                if (empty($视频封面) || !filter_var($视频封面, FILTER_VALIDATE_URL)) {
                    $视频封面 = $默认图片[$图片索引];
                }
                
                $播放来源 = '直播源';
                if (!empty($当前分组)) {
                    $播放来源 = $当前分组;
                }
                
                if (strpos($行, 'magnet:') === 0) {
                    $播放来源 = '🧲磁力链接';
                } elseif (strpos($行, 'ed2k://') === 0) {
                    $播放来源 = '⚡电驴链接';
                }
                
                $视频 = [
                    'vod_id' => 'm3u_' . md5($文件路径) . '_' . $当前行,
                    'vod_name' => $当前名称,
                    'vod_pic' => $视频封面,
                    'vod_remarks' => '直播',
                    'vod_year' => date('Y'),
                    'vod_area' => '中国大陆',
                    'vod_content' => $当前名称 . '直播频道',
                    'vod_play_from' => $播放来源,
                    'vod_play_url' => '直播$' . $行
                ];
                break;
            }
            
            $当前名称 = '';
            $当前图标 = '';
            $当前分组 = '';
        }
    }
    
    fclose($句柄);
    
    return $视频;
}

/**
 * 在数据库文件中按索引查找视频 - 增强磁力链接支持
 */
function 按索引查找数据库视频($文件路径, $表名, $视频索引) {
    if (!file_exists($文件路径) || !extension_loaded('pdo_sqlite')) {
        return null;
    }
    
    try {
        $数据库 = new PDO("sqlite:" . $文件路径);
        $数据库->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $字段列表 = $数据库->query("PRAGMA table_info($表名)")->fetchAll(PDO::FETCH_ASSOC);
        $字段名称 = array_column($字段列表, 'name');
        
        $名称字段 = null;
        $链接字段 = null;
        $磁力字段 = null;
        $电驴字段 = null;
        $图片字段 = null;
        $描述字段 = null;
        $年份字段 = null;
        $地区字段 = null;
        $JSON字段 = null;
        
        foreach ($字段名称 as $字段) {
            $小写字段 = strtolower($字段);
            if (in_array($小写字段, ['name', 'title', 'vod_name', 'filename', 'video_name'])) {
                $名称字段 = $字段;
            } elseif (in_array($小写字段, ['url', 'link', 'vod_url', 'play_url', 'video_url', 'torrent'])) {
                $链接字段 = $字段;
            } elseif (in_array($小写字段, ['magnet', 'magnet_url', 'magnet_link'])) {
                $磁力字段 = $字段;
            } elseif (in_array($小写字段, ['ed2k', 'ed2k_url', 'ed2k_link'])) {
                $电驴字段 = $字段;
            } elseif (in_array($小写字段, ['pic', 'image', 'cover', 'vod_pic', 'poster'])) {
                $图片字段 = $字段;
            } elseif (in_array($小写字段, ['desc', 'description', 'content', 'vod_content'])) {
                $描述字段 = $字段;
            } elseif (in_array($小写字段, ['year', 'vod_year'])) {
                $年份字段 = $字段;
            } elseif (in_array($小写字段, ['area', 'region', 'vod_area'])) {
                $地区字段 = $字段;
            } elseif (in_array($小写字段, ['json', 'data', 'vod_data'])) {
                $JSON字段 = $字段;
            }
        }
        
        if ($名称字段) {
            $选择字段 = [$名称字段];
            if ($链接字段) $选择字段[] = $链接字段;
            if ($磁力字段) $选择字段[] = $磁力字段;
            if ($电驴字段) $选择字段[] = $电驴字段;
            if ($图片字段) $选择字段[] = $图片字段;
            if ($描述字段) $选择字段[] = $描述字段;
            if ($年份字段) $选择字段[] = $年份字段;
            if ($地区字段) $选择字段[] = $地区字段;
            if ($JSON字段) $选择字段[] = $JSON字段;
            
            $查询SQL = "SELECT " . implode(', ', $选择字段) . " FROM $表名 LIMIT 1 OFFSET " . intval($视频索引);
            
            $语句 = $数据库->query($查询SQL);
            $行数据 = $语句->fetch(PDO::FETCH_ASSOC);
            
            if ($行数据) {
                $默认图片 = [
                    'https://www.252035.xyz/imgs?t=1335527662'
                ];
                
                $视频名称 = $行数据[$名称字段] ?? '未知视频';
                
                if ($JSON字段 && !empty($行数据[$JSON字段])) {
                    $json数据 = json_decode($行数据[$JSON字段], true);
                    if ($json数据 && isset($json数据['name']) && empty($视频名称)) {
                        $视频名称 = $json数据['name'];
                    }
                }
                
                $视频链接 = '';
                $播放来源 = '数据库源';
                
                if ($磁力字段 && !empty($行数据[$磁力字段])) {
                    $视频链接 = $行数据[$磁力字段];
                    $播放来源 = '🧲磁力链接';
                } elseif ($电驴字段 && !empty($行数据[$电驴字段])) {
                    $视频链接 = $行数据[$电驴字段];
                    $播放来源 = '⚡电驴链接';
                } elseif ($链接字段 && !empty($行数据[$链接字段])) {
                    $视频链接 = $行数据[$链接字段];
                    if (strpos($视频链接, 'magnet:') === 0) {
                        $播放来源 = '🧲磁力链接';
                    } elseif (strpos($视频链接, 'ed2k://') === 0) {
                        $播放来源 = '⚡电驴链接';
                    }
                }
                
                if (empty($视频链接)) {
                    $数据库 = null;
                    return null;
                }
                
                $视频封面 = $行数据[$图片字段] ?? $默认图片[intval($视频索引) % count($默认图片)];
                $视频描述 = $行数据[$描述字段] ?? '《' . $视频名称 . '》的精彩内容';
                $视频年份 = $行数据[$年份字段] ?? date('Y');
                $视频地区 = $行数据[$地区字段] ?? '中国大陆';
                
                $视频 = [
                    'vod_id' => 'db_' . md5($文件路径) . '_' . $表名 . '_' . $视频索引,
                    'vod_name' => $视频名称,
                    'vod_pic' => $视频封面,
                    'vod_remarks' => '高清',
                    'vod_year' => $视频年份,
                    'vod_area' => $视频地区,
                    'vod_content' => $视频描述,
                    'vod_play_from' => $播放来源,
                    'vod_play_url' => '正片$' . $视频链接
                ];
                
                $数据库 = null;
                return $视频;
            }
        }
        
        $数据库 = null;
        return null;
        
    } catch (PDOException $异常) {
        return null;
    }
}

/**
 * 搜索
 */
function 搜索($关键词, $页码) {
    if (empty($关键词)) {
        return ['错误' => '请输入搜索关键词'];
    }
    
    $搜索结果 = [];
    $所有文件 = 获取所有文件();
    
    $搜索限制 = 3;
    $已搜索文件 = 0;
    
    foreach ($所有文件 as $文件) {
        if ($已搜索文件 >= $搜索限制) {
            break;
        }
        
        $视频列表 = [];
        switch ($文件['type']) {
            case 'json':
                $视频列表 = 解析JSON文件($文件['path']);
                break;
            case 'txt':
                $视频列表 = 解析TXT文件($文件['path']);
                break;
            case 'm3u':
                $视频列表 = 解析M3U文件($文件['path']);
                break;
            case 'db':
                $视频列表 = 解析数据库文件($文件['path']);
                break;
        }
        
        if (isset($视频列表['错误'])) {
            continue;
        }
        
        $文件匹配数 = 0;
        foreach ($视频列表 as $视频) {
            if (stripos($视频['vod_name'] ?? '', $关键词) !== false) {
                $搜索结果[] = 格式化视频项($视频);
                $文件匹配数++;
                
                if (count($搜索结果) >= 30) {
                    break 2;
                }
            }
        }
        
        $已搜索文件++;
    }
    
    if (empty($搜索结果)) {
        return ['错误' => '未找到相关视频内容'];
    }
    
    $每页大小 = 10;
    $总数 = count($搜索结果);
    $总页数 = ceil($总数 / $每页大小);
    $当前页码 = intval($页码);
    
    if ($当前页码 < 1) $当前页码 = 1;
    if ($当前页码 > $总页数) $当前页码 = $总页数;
    
    $起始位置 = ($当前页码 - 1) * $每页大小;
    $分页结果 = array_slice($搜索结果, $起始位置, $每页大小);
    
    return [
        'page' => $当前页码,
        'pagecount' => $总页数,
        'limit' => $每页大小,
        'total' => $总数,
        'list' => $分页结果
    ];
}

/**
 * 格式化视频详情
 */
function 格式化视频详情($视频) {
    return [
        'vod_id' => $视频['vod_id'] ?? '',
        'vod_name' => $视频['vod_name'] ?? '未知视频',
        'vod_pic' => $视频['vod_pic'] ?? 'https://www.252035.xyz/imgs?t=1335527662',
        'vod_remarks' => $视频['vod_remarks'] ?? '高清',
        'vod_year' => $视频['vod_year'] ?? '',
        'vod_area' => $视频['vod_area'] ?? '中国大陆',
        'vod_director' => $视频['vod_director'] ?? '',
        'vod_actor' => $视频['vod_actor'] ?? '',
        'vod_content' => $视频['vod_content'] ?? '视频详情内容',
        'vod_play_from' => $视频['vod_play_from'] ?? 'default',
        'vod_play_url' => $视频['vod_play_url'] ?? ''
    ];
}

/**
 * 获取播放地址 - 增强磁力链接支持
 */
function 获取播放($标志, $标识) {
    // 直接返回播放地址，TVBox播放器会处理磁力链接和ed2k链接
    return [
        'parse' => 0,
        'playUrl' => '',
        'url' => $标识,
        'type' => 'video'
    ];
}
?>