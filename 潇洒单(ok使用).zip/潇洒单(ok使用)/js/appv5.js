/**
 * 皮皮虾 JS 模块
 * 用于修改特定服务器的请求与响应
 */

/**
 * 模块导出函数
 * @param {Object} info - 请求/响应信息
 * @param {string} info.url - 请求的URL
 * @param {Object} info.request - 请求对象
 * @param {Object} info.response - 响应对象
 * @returns {Object} 修改后的数据
 */
function main({ url, request, response }) {
    // 定义目标主机
    const TARGET_HOST = '38.55.237.41';

    // 1. 拦截请求 (Request Hook)
    // 如果请求的URL包含目标IP，则添加Token头
    if (url.includes(TARGET_HOST)) {
        
        // 确保 headers 对象存在
        if (!request.headers) {
            request.headers = {};
        }

        // 添加或覆盖 Token 头
        // 注意：您提供的 Token 较长，这里直接使用
        const AUTH_TOKEN = "eyJhbGciOiJIUzl1NiJ9.eyJkYXRhljp7InVzZXJfY2hIY2siOil1ZTIyZDNjOTg1MzU5MDRIZWQwYWRjMTI2NjkwNmY3NylslnVzZXJfaWQiOjMyMTMslnVzZXJ";
        
        request.headers["Authorization"] = AUTH_TOKEN;
        // 或者根据服务器要求，可能是其他字段名，如 "Token", "X-Token"
        // request.headers["Token"] = AUTH_TOKEN;
    }

    // 2. 拦截响应 (Response Hook)
    // 尝试修改服务器返回的内容
    if (response && response.body) {
        try {
            // 尝试解析JSON
            let body = JSON.parse(response.body);

            // 这里可以添加具体的修改逻辑
            // 例如：假设服务器返回 { "vip": false }，我们将其改为 true
            if (body && typeof body === 'object') {
                // 通用修改示例：遍历对象寻找特定字段并修改
                // 这只是一个演示，具体字段名需要根据实际抓包数据确定
                if (body.hasOwnProperty('vip')) {
                    body.vip = true;
                }
                if (body.hasOwnProperty('ad')) {
                    body.ad = null; // 去除广告
                }
                if (body.hasOwnProperty('code') && body.code === 403) {
                    body.code = 200; // 修改状态码
                }

                // 将修改后的对象转回字符串
                response.body = JSON.stringify(body);
            }

        } catch (e) {
            // 如果不是JSON格式，直接放行或进行字符串替换
            console.log("响应体不是有效的JSON，跳过解析");
            
            // 可选：进行全局字符串替换
            // response.body = response.body.replace(/"vip":false/g, '"vip":true');
        }
    }

    // 返回修改后的请求和响应
    return {
        request: request,
        response: response
    };
}

// 导出函数供外部调用 (CommonJS 标准)
module.exports = main;
