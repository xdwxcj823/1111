function main(item) {
    // 获取频道ID，默认值为cctv1
    var id = item.id || "cctv1";
    
    // 频道名称映射表
    var n = {
        'cctv1': 'CCTV1',
        'cctv2': 'CCTV2',
        'cctv3': 'CCTV3',
        'cctv4': 'CCTV4',
        'cctv5': 'CCTV5',
        'cctv5p': 'CCTV5+',
        'cctv6': 'CCTV6',
        'cctv7': 'CCTV7',
        'cctv8': 'CCTV8',
        'cctv9': 'CCTV9',
        'cctv10': 'CCTV10',
        'cctv11': 'CCTV11',
        'cctv12': 'CCTV12',
        'cctv13': 'CCTV13',
        'cctv14': 'CCTV14',
        'cctv15': 'CCTV15',
        'cctv17': 'CCTV17',
        'cctv4o': 'CCTV4欧洲',
        'cctv4a': 'CCTV4美洲',
        'hunws': '湖南卫视',
        'zjws': '浙江卫视',
        'jsws': '江苏卫视',
        'dfws': '东方卫视',
        'gdws': '广东卫视',
        'hubws': '湖北卫视',
        'jxws': '江西卫视',
        'lnws': '辽宁卫视',
        'shanxws': '陕西卫视',
        'hnws': '河南卫视',
        'hinws': '海南卫视',
        'ssws': '三沙卫视',
        'jlws': '吉林卫视',
        'qhws': '青海卫视',
        'nlws': '农林卫视',
        'nmgws': '内蒙古卫视',
        'btws': '**卫视',
        'dwqws': '大湾区卫视',
        'bjws': '北京卫视',
        'szws': '深圳卫视',
        'sz4k': '苏州4K',
        'heb4k': '河北4K',
        'chcjtyy': 'CHC家庭影院',
        'chcdzdy': 'CHC动作电影',
        'chcymdy': 'CHC影迷电影',
        'wxty': '五星体育',
        'wcjd': '重温经典',
        'xpfyt': '新片放映厅',
        'gqdp': '高清大片',
        'jdxd': '经典香港电影',
        'kzjdyp': '抗战经典**',
        'sszyj': '赛事最经典',
        'wssj': '武术世界',
        'shdy': '四海钓鱼',
        'hqly': '环球旅游',
        'zqzynp': '最强综艺趴',
        'jjkt': '嘉佳卡通',
        'jddhdjh': '经典动画大集合',
        'ymkt': '优漫卡通',
        'cftx': '财富天下',
        'ttmlh': '体坛名栏汇',
        '24xsqyhlbt': '24小时全运会轮播台',
        '24xscsllbt': '24小时城市联赛轮播台',
        'sdjy': '山东教育',
        'zxs': '中学生',
        'lgs': '老故事',
        'cetv1': 'CETV1',
        'cetv2': 'CETV2',
        'cetv4': 'CETV4',
        'xdlclyl': '新动力量创一流',
        'qtj': '钱塘江',
        'kksr': '卡酷少儿',
        'bjys': '北京影视',
        'bjwy': '北京文艺',
        'bjcj': '北京财经',
        'bjsh': '北京生活',
        'bjxw': '北京新闻',
        'bjjskj': '北京纪实科教',
        'hnly': '河南梨园',
        'henxw': '河南新闻',
        'hnds': '河南都市',
        'hnms': '河南民生',
        'hndsj': '河南电视剧',
        'hengg': '河南公共',
        'hnws': '河南武术',
        'hnydxq': '河南移动戏曲',
        'hnwwbk': '河南文物宝库',
        'hnxsj': '河南象视界',
        'gdty': '广东体育',
        'gdzj': '广东珠江',
        'gdse': '广东少儿',
        'lnxq': '岭南戏曲',
        'gdyd': '广东移动',
        'xdjy': '现代教育',
        'gdshpd': '广东生活频道',
        'shxwzh': '上海新闻综合',
        'shdycj': '上海第一财经',
        'shxjs': '上海新纪实',
        'shds': '上海都市',
        'hhxd': '哈哈炫动',
        'shmdy': '上海魔都眼',
        'ash': '爱上海',
        'hinxw': '海南新闻',
        'hinwl': '海南文旅',
        'hinzm': '海南自贸',
        'hingg': '海南公共',
        'hinse': '海南少儿',
        'zjggxw': '浙江公共新闻',
        'zjgj': '浙江国际',
        'zjse': '浙江少儿',
        'zjjksy': '浙江教科影视',
        'zjjl': '之江纪录',
        'zjmsxx': '浙江民生休闲',
        'zjjsh': '浙江经视',
        'zjqjds': '浙江钱江都市',
        'nmgnm': '内蒙古农牧',
        'nmgxwzh': '内蒙古新闻综合',
        'nmgwtly': '内蒙古文体娱乐',
        'nmgjjsh': '内蒙古经济生活',
        'nmgyws': '内蒙古蒙语卫视',
        'nmgywh': '内蒙古蒙语文化',
        'jsgj': '江苏国际',
        'jszy': '江苏综艺',
        'jsys': '江苏影视',
        'jsjy': '江苏教育',
        'jsty': '江苏体育',
        'njxwzh': '南京新闻综合',
        'njjk': '南京教科',
        'njsh': '南京十八',
        'ycxwzh': '盐城新闻综合',
        'haxwzh': '淮安新闻综合',
        'tzxwzh': '泰州新闻综合',
        'lygxwzh': '连云港新闻综合',
        'sqxwzh': '宿迁新闻综合',
        'xzxwzh': '徐州新闻综合',
        'jyxwzh': '江阴新闻综合',
        'ntxwzh': '南通新闻综合',
        'yxxwzh': '宜兴新闻综合',
        'lsxwzh': '溧水新闻综合',
        'sxylpd': '陕西银龄频道',
        'sxdsqc': '陕西都市青春频道',
        'sxqqpd': '陕西秦腔频道',
        'sxzxpd': '陕西新闻资讯频道',
        'fhzw': '凤凰中文',
        'fhzx': '凤凰资讯',
        'fhhk': '凤凰香港',
        'fct': '翡翠台',
        'fct4k': '翡翠台4K',
        'wxxw': '无线新闻',
        'nowxwt': 'Now新闻台',
        'tvgplus': 'TVB Plus',
        'mzt': '明珠台',
        'tvgxh': 'TVB星河',
        'tvg gf': 'TVB功夫',
        'bdjk': '八度空间',
        'chu': 'CHU',
        'ch5': 'CH5',
        'ch8': 'CH8',
        'asam': '澳视澳门',
        'hoy77': 'HOY77'
    };
    
    // 获取目标频道名称
    var targetId = n[id] || n["cctv1"];
    
    // 获取M3U8列表内容
    var m3u8Url = "https://bc.188766.xyz/?ip=";
    var m3u8Content = ku9.get(m3u8Url, null);
    
    // 分割M3U8内容为行数组
    var channels = m3u8Content.split(/\r\n|\r|\n/);
    
    // 移除第一行（可能是#EXTM3U）
    if (channels.length > 0 && channels[0].indexOf("#EXTM3U") === 0) {
        channels.shift();
    }
    
    var liveUrl = "";
    
    // 遍历查找目标频道
    for (var i = 0; i < channels.length; i++) {
        var line = channels[i].trim();
        
        // 检查是否是频道信息行且包含目标频道名称
        if (line.indexOf("#EXTINF:") === 0 && line.indexOf(targetId) !== -1) {
            // 下一行应该是播放地址
            if (i + 1 < channels.length) {
                liveUrl = channels[i + 1].trim();
                break;
            }
        }
    }
    
    // 如果找到直播地址，返回播放地址
    if (liveUrl) {
        return {
            url: liveUrl
        };
    } else {
        // 如果没有找到，返回错误信息或默认地址
        return {
            url: "",
            error: "频道未找到: " + targetId
        };
    }
}